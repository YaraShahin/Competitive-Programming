# Competitive Programming

[Tips](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Tips%20b6c3a8ceb24a4520bbce84413336b435.md)

[GitHub - YaraShahin/Competitve-Programming: My C++ answers to competitive programming problems across different levels](https://github.com/YaraShahin/Competitve-Programming)

# Analysis

[Bootstrapping](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Bootstrapping%202f921e957ef84e2e8b2beae05682ed24.md)

[Complexity Analysis](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Complexity%20Analysis%20b0d3b04a2d754639a3b724c8478530df.md)

[Errors](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Errors%206ac3ff3931d74ce1aace513038b81cce.md)

# Language syntax

[Introduction](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Introduction%203a62377bc60e4bcda89f6fda08fc2c86.md)

[Data Types](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Data%20Types%20e5b738de503142bda6bb787a6785f503.md)

[Math operations](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Math%20operations%205d58a7d26a4945a587e222f3c2619752.md)

[Conditions](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Conditions%204b6fc8774e154c86acb19a66337b154c.md)

[Loops](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Loops%2070f2f56e650c48b489402a0b6aec1a75.md)

# Data structures

## Linear

[Arrays](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Arrays%208d69ea28ab0f4142ab201d3b78a074ac.md)

[Strings](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Strings%2057a323f0144c461096a7f490e614adb2.md)

## Non-linear

[Set](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Set%2066330141c093420eba586ca85fca58c1.md)

# Algorithms

[Recursion](Competitive%20Programming%200b0d2048c407447c8536ea0dd7766342/Recursion%20c5f41793038a4891921f53e4cf0cf2ba.md)