# Errors

# Types of errors

## Syntax errors

- when you get the language grammatical rules wrong, such as:
    - forgetting a curly bracket or a semicolon.
    - using square brackets to call a function.
    - Getting the number of required arguments or their types wrong.
    - Forgetting a return statement
- The compiler will tell you that the program cannot run because of an error.

## Semantic error

- The program runs normally but the output is not expected.
- You wrote the wrong code for this output, however it is grammatically correct.

## Runtime error

- The program runs but it never completes the run, instead it crashes.
- Could be caused by:
    - Infinite loop
    - Dividing by zero