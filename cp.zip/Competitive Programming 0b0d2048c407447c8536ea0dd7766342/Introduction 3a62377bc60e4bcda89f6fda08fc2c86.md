# Introduction

[CoachAcademySlides.pdf](Introduction%203a62377bc60e4bcda89f6fda08fc2c86/CoachAcademySlides.pdf)

# Computer languages

- Machine Language: zeros and ones
- Low-level language: assembly, concerned with memory management and scheduling
- High-level language: C/C++, Python, Java,...

# Compiler vs. Interpreter

- Compiler: checks for errors and executes once for the whole program. Builds slower only once but then executes faster. Such as C/C++, assembly,...
- Interpreter: checks for errors and executes line-by-line. Builds faster but every time.

# My C++ template

```cpp

```

## Main

```cpp
int main(){

    return 0;
}
```

## Input/Output

```cpp
#include <iostream>
using namespace std;

std::cin>>var;
std::cout<<var;
```

## Aliasing

```cpp
typedef long long ll;
```

```cpp
#define endl '\n'
```

# Scopes

- A new scope is created with every opening of a curly brace
- see the difference:

```cpp
#include <iostream>
using namespace std;

int main(){

int x = 5;
{
	x = 3;        //shadowing (narrower scope)
}
cout<<x;        //output: 3

return 0;
}
```

```cpp
#include <iostream>
using namespace std;

int main(){

int x = 5;
{
	int x = 3;    //new variable in scope
}
cout<<x;        //output: 5

return 0;
}
```