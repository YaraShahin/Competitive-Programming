# Bootstrapping

[https://www.youtube.com/watch?v=PjeE8Bc96HY](https://www.youtube.com/watch?v=PjeE8Bc96HY)